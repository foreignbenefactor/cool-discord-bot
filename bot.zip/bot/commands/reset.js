const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db'); // Make sure this path is correct

module.exports = {
    data: new SlashCommandBuilder()
        .setName('reset')
        .setDescription('Reset a user\'s balance and stats (Admin only)')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to reset')
                .setRequired(true))
        .setDefaultMemberPermissions(0), // Admin-only by default
    async execute(interaction) {
        // Configuration - Replace with your admin role ID
        const ADMIN_ROLE_ID = '1353800793576177817';

        // Check permissions
        if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID)) {
            return interaction.reply({
                content: '❌ You need admin privileges to use this command.',
                ephemeral: true
            });
        }

        const targetUser = interaction.options.getUser('user');

        try {
            // First ensure user exists
            await new Promise((resolve, reject) => {
                db.run(
                    `INSERT OR IGNORE INTO users (userId) VALUES (?)`,
                    [targetUser.id],
                    (err) => err ? reject(err) : resolve()
                );
            });

            // Reset all stats
            await new Promise((resolve, reject) => {
                db.run(`
                    UPDATE users SET
                        balance = 0,
                        deposited = 0,
                        withdrawn = 0,
                        wagered = 0,
                        profit = 0,
                        affiliateCount = 0,
                        affiliateEarnings = 0,
                        tipsReceived = 0,
                        tipsSent = 0,
                        totalRained = 0,
                        rainEarnings = 0,
                        level = 0
                    WHERE userId = ?
                `, [targetUser.id], (err) => err ? reject(err) : resolve());
            });

            // Get confirmation data
            const userData = await new Promise((resolve, reject) => {
                db.get(
                    'SELECT * FROM users WHERE userId = ?',
                    [targetUser.id],
                    (err, row) => err ? reject(err) : resolve(row)
                );
            });

            // Create confirmation embed
            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('✅ Account Reset Complete')
                .setDescription(`All stats for ${targetUser.tag} have been reset to zero.`)
                .addFields(
                    { name: 'Reset Balance', value: '`0`', inline: true },
                    { name: 'Reset Level', value: '`0`', inline: true },
                    { name: 'Reset Tips', value: 'Received: `0` | Sent: `0`', inline: false }
                )
                .setFooter({ text: `Admin: ${interaction.user.tag}` })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Reset error:', error);
            await interaction.reply({
                content: '❌ Failed to reset user stats. Please try again.',
                ephemeral: true
            });
        }
    }
};