const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../database.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('balance')
        .setDescription("Check anyone's balance")
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to check (leave empty for yourself)')
                .setRequired(false)),
    async execute(interaction) {
        const targetUser = interaction.options.getUser('user') || interaction.user;
        const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

        const formatNumber = (num) => {
            if (num >= 1000000000) return `${(num/1000000000).toFixed(2)}B`;
            if (num >= 1000000) return `${(num/1000000).toFixed(2)}M`;
            return num.toLocaleString();
        };

        db.get('SELECT * FROM users WHERE userId = ?', [targetUser.id], (err, row) => {
            if (err) {
                console.error(err);
                return interaction.reply('Error fetching balance data.');
            }

            if (!row) {
                db.run(`INSERT INTO users (userId) VALUES (?)`, [targetUser.id], (err) => {
                    if (err) return interaction.reply('Error creating user data.');
                    this.execute(interaction);
                });
                return;
            }

            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setAuthor({ 
                    name:  `MM2Rolls - Balance`, 
                    iconURL: 'https://www.games.rs/files/thumbs/files/images/product/thumbs_800/Monitor-Dell-27-AW2724HF-Black-Srbija-prodaja-cena-GAD520__6_800_1000px.jpg.webp' 
                })
                .setTitle(`${targetMember?.displayName || targetUser.username}'s Balance`)
                .setThumbnail(targetUser.displayAvatarURL())
                .addFields(
                    // Main financial stats
                    { name: 'Balance', value: `\`${formatNumber(row.balance)}\``, inline: true },
                    { name: 'Deposited', value: `\`${formatNumber(row.deposited)}\``, inline: true },
                    { name: 'Withdrawn', value: `\`${formatNumber(row.withdrawn)}\``, inline: true },
                    { name: 'Wagered', value: `\`${formatNumber(row.wagered)}\``, inline: true },
                    { name: 'Profit', value: `\`${formatNumber(row.profit)}\``, inline: true },
                    
                    // New tip stats
                    { name: 'Tips Received', value: `\`${formatNumber(row.tipsReceived || 0)}\``, inline: true },
                    { name: 'Tips Sent', value: `\`${formatNumber(row.tipsSent || 0)}\``, inline: true },
                    
                    // Additional info
                    { name: 'Roblox Account', value: `\`${row.robloxUsername || 'None'}\``, inline: true },
                    { name: 'Level', value: `\`${row.level}\``, inline: true }
                )
                .setFooter({ 
                    text: `Requested by ${interaction.user.username}`,
                    iconURL: interaction.user.displayAvatarURL() 
                })
                .setTimestamp();

            interaction.reply({ embeds: [embed] });
        });
    }
};