const { SlashCommandBuilder } = require('discord.js');
const db = require('../database.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('changelevel')
        .setDescription('Change a user\'s level')
        .addUserOption(option =>
            option.setName('user')
                .setDescription('The user to change the level of')
                .setRequired(true))
        .addIntegerOption(option =>
            option.setName('level')
                .setDescription('The new level')
                .setRequired(true)),
    async execute(interaction) {
        // Check if the user has the required role
        const allowedRole = 'Admin'; // Replace with your role name
        if (!interaction.member.roles.cache.some(role => role.name === allowedRole)) {
            return interaction.reply({ content: 'You do not have permission to use this command.', ephemeral: true });
        }

        const targetUser = interaction.options.getUser('user');
        const newLevel = interaction.options.getInteger('level');

        // Update the user's level in the database
        db.run(`
            UPDATE users SET level = ? WHERE userId = ?
        `, [newLevel, targetUser.id], (err) => {
            if (err) {
                console.error(err);
                return interaction.reply('An error occurred while updating the user\'s level.');
            }

            interaction.reply(`Successfully updated ${targetUser.username}'s level to **${newLevel}**.`);
        });
    },
};