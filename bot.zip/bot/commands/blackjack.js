const { SlashCommandBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, EmbedBuilder } = require('discord.js');
const db = require('../database.js');

// Card values and suits
const suits = ['♥', '♦', '♠', '♣'];
const values = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

// Casino-favorable rules
const HOUSE_RULES = {
    blackjackPayout: 1.5, // Standard 3:2 payout (1.5x bet)
    dealerHitsSoft17: true, // Dealer hits on soft 17 (increases house edge)
    doubleAfterSplit: false, // Cannot double after splitting (increases house edge)
    doubleOnlyOn: [9, 10, 11], // Can only double on 9-11 (like European rules)
    surrender: false, // No surrender option (increases house edge)
    pushOn22: false // Dealer does NOT push on 22 (some new variants have this)
};

module.exports = {
    data: new SlashCommandBuilder()
        .setName('blackjack')
        .setDescription('Play a game of Blackjack')
        .addIntegerOption(option =>
            option.setName('bet')
                .setDescription('Amount to bet')
                .setRequired(true)
                .setMinValue(1)),
    async execute(interaction) {
        const betAmount = interaction.options.getInteger('bet');
        const userId = interaction.user.id;

        await interaction.deferReply();

        db.get('SELECT balance FROM users WHERE userId = ?', [userId], async (err, row) => {
            if (err) return interaction.editReply({ content: 'Database error' });
            if (!row || row.balance < betAmount) {
                return interaction.editReply({
                    content: '❌ Not enough balance for this bet!',
                });
            }

            // Deduct bet with house advantage considerations
            await db.run(`
                UPDATE users SET 
                    balance = balance - ?,
                    wagered = wagered + ?,
                    lastWagered = lastWagered + ?
                WHERE userId = ?
            `, [betAmount, betAmount, betAmount, userId]);

            // Initialize game with 6 decks (like casinos)
            const deck = createMultiDeck(6);
            const playerHand = [drawCard(deck), drawCard(deck)];
            const dealerHand = [drawCard(deck), drawCard(deck)];

            // Check for immediate blackjack (natural)
            const playerTotal = calculateHand(playerHand);
            if (playerTotal === 21) {
                // Only pay if dealer doesn't also have blackjack
                const dealerTotal = calculateHand(dealerHand);
                if (dealerTotal !== 21) {
                    const winAmount = Math.floor(betAmount * HOUSE_RULES.blackjackPayout);
                    await db.run(`
                        UPDATE users SET 
                            balance = balance + ?,
                            wagered = wagered + ?,
                            lastWagered = lastWagered + ?
                        WHERE userId = ?
                    `, [winAmount, betAmount, betAmount, userId]);
                    
                    const embed = createEmbed(interaction, playerHand, dealerHand, betAmount, true)
                        .setTitle('BLACKJACK! (3:2 Payout)')
                        .setColor(0x00FF00)
                        .addFields({ name: 'Payout', value: `+${winAmount.toLocaleString()}` });
                    
                    return interaction.editReply({ embeds: [embed] });
                }
            }

            // Create buttons with casino limitations
            const canDouble = HOUSE_RULES.doubleOnlyOn.includes(calculateHand(playerHand)) && 
                            row.balance >= betAmount * 2;

            const buttons = new ActionRowBuilder()
                .addComponents(
                    new ButtonBuilder()
                        .setCustomId(`hit_${interaction.id}`)
                        .setLabel('Hit')
                        .setStyle(ButtonStyle.Primary),
                    new ButtonBuilder()
                        .setCustomId(`stand_${interaction.id}`)
                        .setLabel('Stand')
                        .setStyle(ButtonStyle.Secondary),
                    new ButtonBuilder()
                        .setCustomId(`double_${interaction.id}`)
                        .setLabel(`Double (${betAmount})`)
                        .setStyle(ButtonStyle.Success)
                        .setDisabled(!canDouble)
                );

            // Send initial game state
            const embed = createEmbed(interaction, playerHand, dealerHand, betAmount, false);
            const response = await interaction.editReply({ 
                embeds: [embed], 
                components: [buttons]
            });

            // Button collector
            const collector = response.createMessageComponentCollector({ 
                time: 300_000,
                filter: i => i.user.id === userId && i.customId.endsWith(`_${interaction.id}`)
            });

            collector.on('collect', async i => {
                try {
                    await i.deferUpdate();
                    
                    let newEmbed;
                    let gameEnded = false;

                    switch (i.customId.split('_')[0]) {
                        case 'hit':
                            playerHand.push(drawCard(deck));
                            const currentTotal = calculateHand(playerHand);
                            
                            if (currentTotal > 21) {
                                gameEnded = true;
                                newEmbed = await endGame(interaction, playerHand, dealerHand, betAmount, 0, 'BUST! You lose.', userId);
                            } else {
                                // Re-check if player can still double after hit
                                const canDoubleNow = HOUSE_RULES.doubleOnlyOn.includes(currentTotal) && 
                                                   row.balance >= betAmount * 2;
                                
                                const updatedButtons = new ActionRowBuilder()
                                    .addComponents(
                                        new ButtonBuilder()
                                            .setCustomId(`hit_${interaction.id}`)
                                            .setLabel('Hit')
                                            .setStyle(ButtonStyle.Primary),
                                        new ButtonBuilder()
                                            .setCustomId(`stand_${interaction.id}`)
                                            .setLabel('Stand')
                                            .setStyle(ButtonStyle.Secondary),
                                        new ButtonBuilder()
                                            .setCustomId(`double_${interaction.id}`)
                                            .setLabel(`Double (${betAmount})`)
                                            .setStyle(ButtonStyle.Success)
                                            .setDisabled(!canDoubleNow)
                                    );
                                
                                newEmbed = createEmbed(interaction, playerHand, dealerHand, betAmount, false);
                                
                                await i.editReply({ 
                                    embeds: [newEmbed], 
                                    components: [updatedButtons] 
                                });
                                return;
                            }
                            break;

                        case 'double':
                            await db.run(`
                                UPDATE users SET 
                                    balance = balance - ?,
                                    wagered = wagered + ?,
                                    lastWagered = ?
                                WHERE userId = ?
                            `, [betAmount, betAmount, betAmount, userId]);
                            
                            playerHand.push(drawCard(deck));
                            gameEnded = true;
                            const doubledTotal = calculateHand(playerHand);
                            
                            if (doubledTotal > 21) {
                                newEmbed = await endGame(interaction, playerHand, dealerHand, betAmount * 2, 0, 'BUST! You lose.', userId);
                            } else {
                                newEmbed = await dealerTurn(interaction, deck, playerHand, dealerHand, betAmount * 2, userId);
                            }
                            break;

                        case 'stand':
                            gameEnded = true;
                            newEmbed = await dealerTurn(interaction, deck, playerHand, dealerHand, betAmount, userId);
                            break;
                    }

                    await i.editReply({ 
                        embeds: [newEmbed], 
                        components: gameEnded ? [] : [buttons] 
                    });
                    
                    if (gameEnded) collector.stop();
                } catch (error) {
                    console.error('Error handling interaction:', error);
                }
            });

            collector.on('end', () => {
                try {
                    response.edit({ components: [] }).catch(console.error);
                } catch (error) {
                    console.error('Error ending collector:', error);
                }
            });
        });
    }
};

// Casino-style multi-deck shoe
function createMultiDeck(numDecks) {
    let deck = [];
    for (let i = 0; i < numDecks; i++) {
        for (const suit of suits) {
            for (const value of values) {
                deck.push({ suit, value });
            }
        }
    }
    return shuffleDeck(deck);
}

// More thorough casino-style shuffle
function shuffleDeck(deck) {
    // Multiple shuffle passes
    for (let n = 0; n < 7; n++) {
        for (let i = deck.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [deck[i], deck[j]] = [deck[j], deck[i]];
        }
    }
    
    // Add cut card at ~60-70% through deck (like casinos)
    const cutPosition = Math.floor(deck.length * 0.65);
    deck.cutCardPosition = cutPosition;
    
    return deck;
}

function drawCard(deck) {
    // Check if we've reached the cut card (reshuffle point)
    if (deck.length <= deck.cutCardPosition) {
        console.log('Reshuffling deck...');
        return drawCard(shuffleDeck(createMultiDeck(6)));
    }
    return deck.pop();
}

function calculateHand(hand) {
    let total = 0;
    let aces = 0;
    
    for (const card of hand) {
        if (card.value === 'A') {
            aces++;
            total += 11;
        } else if (['K', 'Q', 'J'].includes(card.value)) {
            total += 10;
        } else {
            total += parseInt(card.value);
        }
    }
    
    while (total > 21 && aces > 0) {
        total -= 10;
        aces--;
    }
    
    return total;
}

function createEmbed(interaction, playerHand, dealerHand, bet, showDealer) {
    const playerTotal = calculateHand(playerHand);
    const dealerTotal = showDealer ? calculateHand(dealerHand) : '?';
    const embedColor = 0x2F3136; // Grey for in-progress
    
    return new EmbedBuilder()
        .setColor(embedColor)
        .setTitle('♠️♥️ Blackjack ♦️♣️')
        .addFields(
            { 
                name: `Your Hand (${playerTotal})`, 
                value: formatHand(playerHand) 
            },
            { 
                name: `Dealer's Hand ${showDealer ? `(${dealerTotal})` : ''}`, 
                value: showDealer ? formatHand(dealerHand) : `${dealerHand[0].value}${dealerHand[0].suit} ❓` 
            },
            { name: 'Current Bet', value: `\`${bet.toLocaleString()}\``, inline: true }
        )
        .setFooter({ 
            text: 'MM2Rolls', 
            iconURL: interaction.client.user.displayAvatarURL() 
        });
}

function formatHand(hand) {
    return hand.map(card => `${card.value}${card.suit}`).join(' ');
}

async function dealerTurn(interaction, deck, playerHand, dealerHand, bet, userId) {
    const playerTotal = calculateHand(playerHand);
    let dealerTotal = calculateHand(dealerHand);
    
    // Casino rule: Dealer hits on soft 17 if configured
    while (dealerTotal < 17 || (HOUSE_RULES.dealerHitsSoft17 && dealerTotal === 17 && hasAce(dealerHand))) {
        dealerHand.push(drawCard(deck));
        dealerTotal = calculateHand(dealerHand);
    }
    
    // Determine winner with house edge
    let result, winAmount = 0;
    if (playerTotal > 21) {
        result = 'BUST! You lose.';
    } else if (dealerTotal > 21) {
        winAmount = bet * (playerTotal === 21 && playerHand.length === 2 ? HOUSE_RULES.blackjackPayout : 2);
        result = `You win ${winAmount.toLocaleString()}!`;
    } else if (playerTotal > dealerTotal) {
        winAmount = bet * 2;
        result = `You win ${winAmount.toLocaleString()}!`;
    } else if (playerTotal === dealerTotal) {
        // House edge: No push on dealer 22 if that rule is enabled
        if (HOUSE_RULES.pushOn22 && dealerTotal === 22) {
            result = 'Dealer 22! You lose.';
        } else {
            winAmount = bet;
            result = 'Push! Bet returned.';
        }
    } else {
        result = 'Dealer wins!';
    }
    
    // Update database if player won
    if (winAmount > 0) {
        await db.run('UPDATE users SET balance = balance + ? WHERE userId = ?', [winAmount, userId]);
    }
    
    const embedColor = playerTotal > 21 || winAmount === 0 ? 0xFF0000 : 0x00FF00;
    
    return createEmbed(interaction, playerHand, dealerHand, bet, true)
        .setTitle(`Game Over - ${result}`)
        .setColor(embedColor)
        .addFields({ name: 'Payout', value: winAmount > 0 ? `+${winAmount.toLocaleString()}` : 'None' });
}

function hasAce(hand) {
    return hand.some(card => card.value === 'A');
}

async function endGame(interaction, playerHand, dealerHand, bet, winAmount, result, userId) {
    if (winAmount > 0) {
        await db.run('UPDATE users SET balance = balance + ? WHERE userId = ?', [winAmount, userId]);
    }
    
    const embedColor = winAmount > 0 ? 0x00FF00 : 0xFF0000;
    
    return createEmbed(interaction, playerHand, dealerHand, bet, true)
        .setTitle(`Game Over - ${result}`)
        .setColor(embedColor)
        .addFields({ name: 'Payout', value: winAmount > 0 ? `+${winAmount.toLocaleString()}` : 'None' });
}