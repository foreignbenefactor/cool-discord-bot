const { SlashCommandBuilder } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('close')
        .setDescription('Close this ticket (removes opener\'s access)'),
    async execute(interaction) {
        // 1. Verify it's a ticket channel
        if (!interaction.channel.name.startsWith('deposit-')) {
            return interaction.reply({
                content: 'This command only works in deposit tickets.',
                ephemeral: true
            });
        }

        try {
            // 2. Get opener's username from channel name
            const openerUsername = interaction.channel.name.replace('deposit-', '');
            
            // 3. Find opener in the server
            const opener = interaction.guild.members.cache.find(m => 
                m.user.username === openerUsername
            );

            // 4. Remove opener's permissions if found
            if (opener) {
                await interaction.channel.permissionOverwrites.delete(opener.id);
                await interaction.reply(`✅ Ticket closed. ${opener.user.tag} can no longer access this channel.`);
            } else {
                await interaction.reply('⚠️ Original opener not found in server.');
            }

        } catch (error) {
            console.error('Close error:', error);
            await interaction.reply('❌ Failed to close ticket.');
        }
    }
};