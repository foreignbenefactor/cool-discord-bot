const { SlashCommandBuilder } = require('discord.js');
const db = require('../database.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('rakeback')
        .setDescription('Claim your rakeback based on your wagered amount'),
    async execute(interaction) {
        const userId = interaction.user.id;
        
        // Get user's current wagered amount
        db.get('SELECT lastWagered FROM users WHERE userId = ?', [userId], async (err, row) => {
            if (err) return interaction.reply('Database error');
            
            if (!row || row.lastWagered <= 0) {
                return interaction.reply({ 
                    content: '❌ You have no rakeback to claim!',
                    ephemeral: true 
                });
            }
            
            // Calculate rakeback (example: 5% of lastWagered)
            const rakebackAmount = Math.floor(row.lastWagered * 0.05);
            
            // Update user balance and reset lastWagered
            await db.run(`
                UPDATE users SET 
                    balance = balance + ?,
                    lastWagered = 0
                WHERE userId = ?
            `, [rakebackAmount, userId]);
            
            await interaction.reply({
                content: `✅ You've claimed ${rakebackAmount.toLocaleString()} in rakeback!`,
                ephemeral: true
            });
        });
    }
};