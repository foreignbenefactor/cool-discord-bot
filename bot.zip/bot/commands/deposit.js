const { SlashCommandBuilder, ChannelType, PermissionFlagsBits } = require('discord.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('deposit')
        .setDescription('Create a deposit ticket')
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('Amount to deposit')
                .setRequired(true)
                .setMinValue(1)),
    async execute(interaction) {
        // CONFIG - Replace these IDs
        const TICKET_CATEGORY_ID = '1353800689754574878';
        const STAFF_ROLE_ID = '1353800793576177817';

        const amount = interaction.options.getInteger('amount');
        const user = interaction.user;

        try {
            const channel = await interaction.guild.channels.create({
                name: `deposit-${user.username}`,
                type: ChannelType.GuildText,
                parent: TICKET_CATEGORY_ID,
                permissionOverwrites: [
                    {
                        id: interaction.guild.id,
                        deny: [PermissionFlagsBits.ViewChannel],
                    },
                    {
                        id: user.id,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    },
                    {
                        id: STAFF_ROLE_ID,
                        allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages],
                    },
                ],
            });

            await channel.send({
                content: `${user} <@&${STAFF_ROLE_ID}>`,
                embeds: [{
                    title: '💰 Deposit Ticket',
                    description: `**Amount:** ${amount.toLocaleString()}\nStaff will assist you shortly.`,
                    color: 0x00FF00,
                    footer: { text: 'Type /close when done' }
                }]
            });

            await interaction.reply({
                content: `Ticket created: ${channel}\nAmount: ${amount.toLocaleString()}`,
                ephemeral: true
            });

        } catch (error) {
            console.error(error);
            await interaction.reply({ content: '❌ Ticket creation failed', ephemeral: true });
        }
    }
};