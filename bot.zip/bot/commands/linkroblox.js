const { SlashCommandBuilder } = require('discord.js');
const db = require('../database.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('linkroblox')
        .setDescription('Link your Roblox account')
        .addStringOption(option =>
            option.setName('username')
                .setDescription('Your Roblox username')
                .setRequired(true)),
    async execute(interaction) {
        const userId = interaction.user.id;
        const robloxUsername = interaction.options.getString('username');

        // Update the user's Roblox username in the database
        db.run(`
            UPDATE users SET robloxUsername = ? WHERE userId = ?
        `, [robloxUsername, userId], (err) => {
            if (err) {
                console.error(err);
                return interaction.reply('An error occurred while linking your Roblox account.');
            }

            interaction.reply(`Successfully linked your Roblox account: **${robloxUsername}**.`);
        });
    },
};