const { SlashCommandBuilder, EmbedBuilder } = require('discord.js');
const db = require('../database.js');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('give')
        .setDescription('Modify user stats (Admin only)')
        .setDefaultMemberPermissions(0) // Admin-only by default
        .addUserOption(option =>
            option.setName('user')
                .setDescription('User to modify')
                .setRequired(true))
        .addStringOption(option =>
            option.setName('stat')
                .setDescription('Stat to modify')
                .setRequired(true)
                .addChoices(
                    { name: 'Balance', value: 'balance' },
                    { name: 'Deposited', value: 'deposited' },
                    { name: 'Withdrawn', value: 'withdrawn' },
                    { name: 'Wagered', value: 'wagered' },
                    { name: 'Profit', value: 'profit' },
                    { name: 'Tips Received', value: 'tipsReceived' },
                    { name: 'Tips Sent', value: 'tipsSent' },
                    { name: 'Level', value: 'level' },
                    { name: 'LastWagered', value: 'lastWagered' }
                ))
        .addIntegerOption(option =>
            option.setName('amount')
                .setDescription('New value')
                .setRequired(true)
                .setMinValue(0)), // Prevent negative values
    async execute(interaction) {
        // Configuration
        const ADMIN_ROLE_ID = '1353800793576177817';

        // Permission check
        if (!interaction.member.roles.cache.has(ADMIN_ROLE_ID)) {
            return interaction.reply({
                content: '❌ You need admin privileges to use this command.',
                ephemeral: true
            });
        }

        const targetUser = interaction.options.getUser('user');
        const stat = interaction.options.getString('stat');
        const amount = interaction.options.getInteger('amount');

        try {
            // 1. First ensure user exists
            await db.run(
                `INSERT OR IGNORE INTO users (userId) VALUES (?)`,
                [targetUser.id]
            );

            // 2. Update the stat
            await db.run(
                `UPDATE users SET ${stat} = ? WHERE userId = ?`,
                [amount, targetUser.id]
            );

            // 3. Get updated data (with error handling)
            const updated = await new Promise((resolve, reject) => {
                db.get(
                    'SELECT * FROM users WHERE userId = ?',
                    [targetUser.id],
                    (err, row) => {
                        if (err) reject(err);
                        resolve(row || {
                            balance: 0,
                            [stat]: amount
                        });
                    }
                );
            });

            // 4. Create confirmation embed
            const embed = new EmbedBuilder()
                .setColor(0x00FF00)
                .setTitle('✅ Stats Updated')
                .addFields(
                    { name: 'User', value: targetUser.tag },
                    { name: 'Modified Stat', value: stat.toUpperCase() },
                    { name: 'New Value', value: amount.toLocaleString() },
                    { name: 'Current Balance', value: (updated.balance || 0).toLocaleString() }
                )
                .setFooter({ text: `Admin: ${interaction.user.tag}` })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (error) {
            console.error('Give command error:', error);
            await interaction.reply({
                content: '❌ Failed to update stats. Please try again.',
                ephemeral: true
            });
        }
    }
};