const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('./database.db');

// Create the users table with all defaults set to 0
db.serialize(() => {
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            userId TEXT PRIMARY KEY,
            balance REAL DEFAULT 0,
            deposited REAL DEFAULT 0,
            withdrawn REAL DEFAULT 0,
            wagered REAL DEFAULT 0,
            lastWagered REAL DEFAULT 0,
            profit REAL DEFAULT 0,
            linkedAccount TEXT DEFAULT 'None',
            affiliateTo TEXT DEFAULT 'None',
            affiliateCount INTEGER DEFAULT 0,
            affiliateEarnings REAL DEFAULT 0,
            tipsReceived REAL DEFAULT 0,
            tipsSent REAL DEFAULT 0,
            totalRained REAL DEFAULT 0,
            rainEarnings REAL DEFAULT 0,
            robloxUsername TEXT DEFAULT 'None',
            level INTEGER DEFAULT 0
        )
    `);
});

module.exports = db;