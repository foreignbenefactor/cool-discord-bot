require('dotenv').config();
const { Client, GatewayIntentBits, REST, Routes } = require('discord.js');

const TOKEN = process.env.TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = '1254163651699544076'; // ← Replace with your server ID

const client = new Client({ 
  intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages] 
});

// Load commands
client.commands = new Map();
const fs = require('fs');
const path = require('path');
const commandsPath = path.join(__dirname, 'commands');
const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));

for (const file of commandFiles) {
  const command = require(path.join(commandsPath, file));
  client.commands.set(command.data.name, command);
}

// Register commands ONLY in your server
async function registerCommands() {
  const commands = Array.from(client.commands.values()).map(cmd => cmd.data.toJSON());
  const rest = new REST({ version: '10' }).setToken(TOKEN);

  try {
    console.log('Deleting old global commands...');
    await rest.put(Routes.applicationCommands(CLIENT_ID), { body: [] }); // Delete global commands
    
    console.log('Registering server-specific commands...');
    await rest.put(
      Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), // Register only in your server
      { body: commands }
    );
    console.log('Commands updated successfully!');
  } catch (error) {
    console.error('Error:', error);
  }
}

// Bot events
client.once('ready', () => {
  console.log(`Logged in as ${client.user.tag}!`);
  registerCommands();
});

client.on('interactionCreate', async interaction => {
  if (!interaction.isCommand()) return;
  const command = client.commands.get(interaction.commandName);
  if (command) await command.execute(interaction);
});

async function nukeCommands() {
  const rest = new REST({ version: '10' }).setToken(TOKEN);
  // Delete global commands
  await rest.put(Routes.applicationCommands(CLIENT_ID), { body: [] });
  // Delete guild commands
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: [] });
  console.log('🗑️ NUKED ALL COMMANDS SUCCESSFULLY!');
}
nukeCommands(); // Uncomment this line, run once, then comment it back

client.login(TOKEN);